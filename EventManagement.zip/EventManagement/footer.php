<div class="footer">
    <p>&copy; <?php echo date("Y"); ?> MyWebsite. All rights reserved.</p>
</div>

<style>
    .footer {
        text-align: center;
        padding: 10px;
        background-color: #333;
        color: #fff;
        position: fixed;
        bottom: 0;
        width: calc(100% - 250px);
        margin-left: 250px;
    }
</style>
