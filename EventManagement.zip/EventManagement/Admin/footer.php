<div class="footer">
    <p>&copy; <?php echo date("Y"); ?> Event Management System(Admin Panel) . All rights reserved.</p>
</div>

<style>
    .footer {
        text-align: center;
        padding: 15px;
        background-color: #2C3E50;
        color: white;
        position: fixed;
        bottom: 0;
        left: 250px; /* Ensures header starts from the right side of sidebar */

        width: calc(100% - 250px);
    }
</style>
